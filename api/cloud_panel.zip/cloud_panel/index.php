<?php
require_once __DIR__ . '/config.php';

// SUPER BASIC SECURE LOGIN FOR DEMO
// In production, change this password or implement a real user table!
define('ADMIN_PASS', 'secureadmin123');

if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: index.php");
    exit;
}

if (!isset($_SESSION['admin_logged_in'])) {
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['password'])) {
        if ($_POST['password'] === ADMIN_PASS) {
            $_SESSION['admin_logged_in'] = true;
            header("Location: index.php");
            exit;
        } else {
            $error = "Invalid Password";
        }
    }
?>
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <title>Cloud Control Panel Login</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    </head>

    <body class="bg-light d-flex align-items-center justify-content-center" style="height: 100vh;">
        <div class="card shadow p-4" style="width: 400px;">
            <h3 class="text-center mb-4">Assesshub Cloud</h3>
            <?php if (isset($error)) echo "<div class='alert alert-danger'>$error</div>"; ?>
            <form method="POST">
                <div class="mb-3">
                    <input type="password" name="password" class="form-control" placeholder="Admin Password" required>
                </div>
                <button type="submit" class="btn btn-primary w-100">Login to Control Panel</button>
            </form>
        </div>
    </body>

    </html>
<?php
    exit;
}

// $db is established in config.php

// Handle Form Submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'add_school') {
        $stmt = $db->prepare("INSERT INTO schools (school_name, license_key, ai_enabled, ai_provider, ai_model, ai_key, sync_enabled, max_devices) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([
            $_POST['school_name'],
            $_POST['license_key'] ? $_POST['license_key'] : strtoupper(substr(md5(uniqid()), 0, 12)) . '-LIC',
            isset($_POST['ai_enabled']) ? 1 : 0,
            $_POST['ai_provider'],
            $_POST['ai_model'],
            $_POST['ai_key'],
            isset($_POST['sync_enabled']) ? 1 : 0,
            (int)$_POST['max_devices']
        ]);
        header("Location: index.php?msg=School+Added");
        exit;
    }
    if ($_POST['action'] === 'edit_school') {
        $stmt = $db->prepare("UPDATE schools SET school_name = ?, ai_enabled = ?, ai_provider = ?, ai_model = ?, ai_key = ?, sync_enabled = ?, max_devices = ?, is_active = ? WHERE id = ?");
        $stmt->execute([
            $_POST['school_name'],
            isset($_POST['ai_enabled']) ? 1 : 0,
            $_POST['ai_provider'],
            $_POST['ai_model'],
            $_POST['ai_key'],
            isset($_POST['sync_enabled']) ? 1 : 0,
            (int)$_POST['max_devices'],
            isset($_POST['is_active']) ? 1 : 0,
            (int)$_POST['school_id']
        ]);
        header("Location: index.php?msg=School+Updated");
        exit;
    }
    if ($_POST['action'] === 'add_version') {
        $stmt = $db->prepare("INSERT INTO app_versions (version_code, is_critical, changelog, download_url) VALUES (?, ?, ?, ?)");
        $stmt->execute([
            $_POST['version_code'],
            isset($_POST['is_critical']) ? 1 : 0,
            $_POST['changelog'],
            $_POST['download_url']
        ]);
        header("Location: index.php?msg=Version+Registered");
        exit;
    }
}

// Fetch all schools
$schools = $db->query("SELECT * FROM schools ORDER BY created_at DESC")->fetchAll();
// Fetch versions
$versions = $db->query("SELECT * FROM app_versions ORDER BY release_date DESC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Assesshub Cloud Control Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .switch {
            position: relative;
            display: inline-block;
            width: 40px;
            height: 20px;
        }

        .switch input {
            opacity: 0;
            width: 0;
            height: 0;
        }

        .slider {
            position: absolute;
            cursor: pointer;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: #ccc;
            transition: .4s;
            border-radius: 20px;
        }

        .slider:before {
            position: absolute;
            content: "";
            height: 16px;
            width: 16px;
            left: 2px;
            bottom: 2px;
            background-color: white;
            transition: .4s;
            border-radius: 50%;
        }

        input:checked+.slider {
            background-color: #2196F3;
        }

        input:checked+.slider:before {
            transform: translateX(20px);
        }
    </style>
</head>

<body class="bg-light">

    <nav class="navbar navbar-dark bg-dark mb-4">
        <div class="container-fluid">
            <span class="navbar-brand mb-0 h1">Assesshub Central Command</span>
            <a href="?logout=1" class="btn btn-outline-light btn-sm">Logout</a>
        </div>
    </nav>

    <div class="container-fluid px-4">
        <?php if (isset($_GET['msg'])) echo '<div class="alert alert-success">' . htmlspecialchars($_GET['msg']) . '</div>'; ?>

        <div class="d-flex justify-content-between align-items-center mb-3">
            <h2>Managed Schools & Licenses</h2>
            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addSchoolModal">+ Add New School</button>
        </div>

        <div class="card shadow-sm">
            <div class="card-body p-0">
                <table class="table table-hover mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>School Name</th>
                            <th>License Key</th>
                            <th>AI Access</th>
                            <th>AI Model</th>
                            <th>Cloud Sync</th>
                            <th>Activated Devices</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($schools as $s):
                            // Count actual devices
                            $dev_stmt = $db->prepare("SELECT count(*) FROM devices WHERE school_id = ?");
                            $dev_stmt->execute([$s['id']]);
                            $device_count = $dev_stmt->fetchColumn();
                        ?>
                            <tr>
                                <td class="fw-bold"><?= htmlspecialchars($s['school_name']) ?></td>
                                <td><code class="text-dark bg-light p-1 rounded"><?= htmlspecialchars($s['license_key']) ?></code></td>
                                <td>
                                    <?php if ($s['ai_enabled']): ?>
                                        <span class="badge bg-success">ON</span>
                                    <?php else: ?>
                                        <span class="badge bg-danger">OFF</span>
                                    <?php endif; ?>
                                </td>
                                <td><small class="text-muted"><?= htmlspecialchars($s['ai_provider']) ?><br><?= htmlspecialchars($s['ai_model']) ?></small></td>
                                <td>
                                    <?php if ($s['sync_enabled']): ?>
                                        <span class="badge bg-success">ON</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary">OFF</span>
                                    <?php endif; ?>
                                </td>
                                <td><?= $device_count ?> / <?= $s['max_devices'] ?></td>
                                <td>
                                    <button class="btn btn-sm btn-outline-primary"
                                        onclick="editSchool(<?= htmlspecialchars(json_encode($s)) ?>)">
                                        Edit
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        <?php if (empty($schools)): ?>
                            <tr>
                                <td colspan="7" class="text-center py-4">No schools added yet.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <hr class="my-5">

        <div class="d-flex justify-content-between align-items-center mb-3">
            <h2>Application Versions (OTA Updates)</h2>
            <button class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#addVersionModal">+ Release New Version</button>
        </div>

        <div class="card shadow-sm mb-5">
            <div class="card-body p-0">
                <table class="table table-hover mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>Version Code</th>
                            <th>Release Date</th>
                            <th>Type</th>
                            <th>Changelog</th>
                            <th>ZIP Package URL</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($versions as $v): ?>
                            <tr>
                                <td class="fw-bold"><?= htmlspecialchars($v['version_code']) ?></td>
                                <td><small class="text-muted"><?= htmlspecialchars($v['release_date']) ?></small></td>
                                <td>
                                    <?php if ($v['is_critical']): ?>
                                        <span class="badge bg-danger">Critical</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary">Optional</span>
                                    <?php endif; ?>
                                </td>
                                <td><small class="text-muted"><?= htmlspecialchars($v['changelog']) ?></small></td>
                                <td>
                                    <a href="<?= htmlspecialchars($v['download_url']) ?>" target="_blank" class="btn btn-sm btn-outline-primary">View ZIP</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        <?php if (empty($versions)): ?>
                            <tr>
                                <td colspan="5" class="text-center py-4">No OTA updates published yet.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Add School Modal -->
    <div class="modal fade" id="addSchoolModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Register New School / License</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <input type="hidden" name="action" value="add_school">

                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label class="form-label">School Name</label>
                                <input type="text" name="school_name" class="form-control" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Custom License Key (Leave blank to auto-generate)</label>
                                <input type="text" name="license_key" class="form-control" placeholder="e.g. SCHOOL-2026-XYZ">
                            </div>
                        </div>

                        <hr>
                        <h6>Features & Limits</h6>

                        <div class="row border p-3 rounded bg-light mb-3">
                            <div class="col-md-4 d-flex flex-column align-items-start">
                                <strong>Enable AI Generator</strong>
                                <label class="switch mt-2">
                                    <input type="checkbox" name="ai_enabled" value="1" checked>
                                    <span class="slider"></span>
                                </label>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">AI Provider</label>
                                <select name="ai_provider" class="form-control">
                                    <option value="openrouter">OpenRouter</option>
                                    <option value="groq">Groq</option>
                                    <option value="openai">OpenAI</option>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">AI Model</label>
                                <input type="text" name="ai_model" class="form-control" value="mistralai/mistral-7b-instruct">
                            </div>
                            <div class="col-12 mt-3">
                                <label class="form-label">Dedicated API Key (Optional. If blank, uses global.)</label>
                                <input type="password" name="ai_key" class="form-control" placeholder="sk-or-v1-...">
                                <small class="text-muted">You can isolate billing by giving a school their own API key.</small>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-4 d-flex flex-column align-items-start">
                                <strong>Enable Cloud Sync</strong>
                                <label class="switch mt-2">
                                    <input type="checkbox" name="sync_enabled" value="1" checked>
                                    <span class="slider"></span>
                                </label>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Max Allowed Devices</label>
                                <input type="number" name="max_devices" class="form-control" value="3" min="1">
                            </div>
                        </div>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Create License</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Add Version Modal -->
    <div class="modal fade" id="addVersionModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Publish OTA Update</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <input type="hidden" name="action" value="add_version">
                        <div class="mb-3">
                            <label class="form-label">Version Code (e.g. 1.0.5)</label>
                            <input type="text" name="version_code" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Direct Download URL (.zip)</label>
                            <input type="url" name="download_url" class="form-control" placeholder="https://bluehost.com/updates/v1.0.5.zip" required>
                        </div>
                        <div class="mb-3 d-flex flex-column align-items-start border p-2 bg-light rounded">
                            <strong>Is Critical Update?</strong>
                            <label class="switch mt-2">
                                <input type="checkbox" name="is_critical" value="1">
                                <span class="slider"></span>
                            </label>
                            <small class="text-muted mt-1">Critical updates force users to update.</small>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Changelog / Release Notes</label>
                            <textarea name="changelog" class="form-control" rows="3"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-warning">Publish to all Schools</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Edit School Modal -->
    <div class="modal fade" id="editSchoolModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Edit School / License</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <input type="hidden" name="action" value="edit_school">
                        <input type="hidden" name="school_id" id="edit_school_id">

                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label class="form-label">School Name</label>
                                <input type="text" name="school_name" id="edit_school_name" class="form-control" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">License Key (Read Only)</label>
                                <input type="text" id="edit_license_key" class="form-control" readonly disabled>
                            </div>
                        </div>

                        <div class="mb-3 d-flex flex-column align-items-start border p-2 bg-light rounded">
                            <strong>License Status</strong>
                            <label class="switch mt-2">
                                <input type="checkbox" name="is_active" id="edit_is_active" value="1">
                                <span class="slider"></span>
                            </label>
                            <small class="text-muted mt-1">Suspend/Activate this school.</small>
                        </div>

                        <hr>
                        <h6>Features & Limits</h6>

                        <div class="row border p-3 rounded bg-light mb-3">
                            <div class="col-md-4 d-flex flex-column align-items-start">
                                <strong>Enable AI Generator</strong>
                                <label class="switch mt-2">
                                    <input type="checkbox" name="ai_enabled" id="edit_ai_enabled" value="1">
                                    <span class="slider"></span>
                                </label>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">AI Provider</label>
                                <select name="ai_provider" id="edit_ai_provider" class="form-control">
                                    <option value="openrouter">OpenRouter</option>
                                    <option value="groq">Groq</option>
                                    <option value="openai">OpenAI</option>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">AI Model</label>
                                <input type="text" name="ai_model" id="edit_ai_model" class="form-control">
                            </div>
                            <div class="col-12 mt-3">
                                <label class="form-label">Dedicated API Key (Optional)</label>
                                <input type="password" name="ai_key" id="edit_ai_key" class="form-control" placeholder="Keep blank to use global">
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-4 d-flex flex-column align-items-start">
                                <strong>Enable Cloud Sync</strong>
                                <label class="switch mt-2">
                                    <input type="checkbox" name="sync_enabled" id="edit_sync_enabled" value="1">
                                    <span class="slider"></span>
                                </label>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Max Allowed Devices</label>
                                <input type="number" name="max_devices" id="edit_max_devices" class="form-control" min="1">
                            </div>
                        </div>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Update School</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function editSchool(school) {
            document.getElementById('edit_school_id').value = school.id;
            document.getElementById('edit_school_name').value = school.school_name;
            document.getElementById('edit_license_key').value = school.license_key;
            document.getElementById('edit_ai_provider').value = school.ai_provider;
            document.getElementById('edit_ai_model').value = school.ai_model;
            document.getElementById('edit_ai_key').value = school.ai_key || '';
            document.getElementById('edit_max_devices').value = school.max_devices;

            document.getElementById('edit_is_active').checked = parseInt(school.is_active) === 1;
            document.getElementById('edit_ai_enabled').checked = parseInt(school.ai_enabled) === 1;
            document.getElementById('edit_sync_enabled').checked = parseInt(school.sync_enabled) === 1;

            const modal = new bootstrap.Modal(document.getElementById('editSchoolModal'));
            modal.show();
        }
    </script>
</body>

</html>