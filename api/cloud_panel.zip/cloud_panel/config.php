<?php
// Database configuration for Bluehost
define('DB_HOST', 'localhost');
define('DB_USER', 'ekmapxmy_oluwagbenga');
define('DB_PASS', 'G.s.o.m.');
define('DB_NAME', 'ekmapxmy_licenses');

// Authentication Helper
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/**
 * Establish Database Connection
 */
try {
    $db = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false
        ]
    );
} catch (PDOException $e) {
    // In production, log this and show a generic message
    die("Database connection failed. Please check your configuration.");
}

/**
 * Legacy wrapper for files still using getDB()
 */
function getDB()
{
    global $db;
    return $db;
}
